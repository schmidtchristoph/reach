library(reach)
library(testthat)

context("Testing examples in documentation")

test_examples()
