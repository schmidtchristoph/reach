#' Starts Matlab on the R console and executes one or several input Matlab
#' commands
#'
#' Starts Matlab on the R console and let it executes the input Matlab command
#' or several input commands, like function calls (separated by ";") and quits
#' Matlab. Discerns the OS X and Linux Matlab app shell command. Automatically
#' changes to the current R working directory in Matlab so that .mat files would
#' be saved there instead of the default Matlab working directory.
#'
#' @param commandName a string denoting the Matlab command
#'
#' @details As R and Matlab cannot directly exchange data natively, no value can
#'   be returned. Instead, let Matlab save the results of its computations and
#'   load these into R for further processing. An error in the Matlab command
#'   prevents Matlab from quitting in the R console and might require killing
#'   the Matlab process or an re-start of the R session. (You migth want to
#'   check the command in Matlab before executing it within R.) The commandName
#'   could look something like this: "load someData.mat;
#'   [ca,Q]=modularity_dir(A); save someData2.mat ca Q; quit"
#'
#' @seealso \code{\link{runMatlabScript}}, \code{\link{convert2RData}}
#'
#' @export
#'
#' @examples
#' \dontrun{
#'
#' commandName <- "x=1:2:7; y=3; disp(x); disp(x.^y); quit"
#' runMatlabCommand(commandName)
#'
#'
#'
#' commandName2 <- "M=magic(4); disp(M); eig(M)"
#' runMatlabCommand(commandName2)
#'
#'
#'
#' wrong_but_corrected_commandName <- "M=magic(4); disp(M); eig(M) quit"
#' runMatlabCommand(wrong_but_corrected_commandName)
#'
#'
#'
#' commandName3 <- "A=magic(3); save('magic.mat', 'A', '-v7'); quit"
#' runMatlabCommand(commandName3)
#' input        <- R.matlab::readMat("magic.mat")
#' print(input$A)
#' invisible(capture.output(file.remove("magic.mat")))
#'
#' }
#'
#' @author Christoph Schmidt <christoph.schmidt@@med.uni-jena.de>

# 10.09.15

runMatlabCommand <- function(commandName){

   #### Checking whether 'quit' has to be appended ####
   ind <- stringr::str_locate(commandName, "quit") # NA if 'quit' is not included

   if(is.na(ind[[1]])){
      commandName <- stringr::str_c(commandName, " ,;quit")

   } else { # ensure Matlab really quits: add ",;" directly preceding "quit" in case neither "," or ";" was put in front of "quit"
      ind2        <- stringr::str_locate(commandName, "quit")
      tmp1        <- stringr::str_sub(commandName, 1, ind2[1,1]-1)
      tmp2        <- stringr::str_sub(commandName, ind2[1,1], stringr::str_length(commandName))
      commandName <- stringr::str_c(tmp1, ",;", tmp2)
   }



   #### Checking whether the commandName ends with \" (if not, then appending it) ####
   lastChar  <- stringr::str_sub(commandName, stringr::str_length(commandName), stringr::str_length(commandName))

   if(!identical(lastChar, "\"")){
      commandName <- stringr::str_c(commandName, "\"")
   }



   #### overriding Matlab default working directory ####
   wd          <- getwd()
   commandName <- stringr::str_c("\"cd ", wd, "; ", commandName)



   #### Selecting Matlab call ####
   si <- Sys.info()

   if (si[['sysname']]=='Darwin') {
      matl       <- getMacMatlab()
      matlabCall <- paste('/Applications/', matl, '/bin/matlab', sep="")


   } else {
      matlabCall <- 'matlab'
   }



   flags      <- ' -nosplash -nodesktop -r '
   systemcall <- paste(matlabCall, flags, commandName, sep="")
   print(systemcall)

   system(systemcall)
}

