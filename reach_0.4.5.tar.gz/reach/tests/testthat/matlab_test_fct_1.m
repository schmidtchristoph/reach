function [ out ] = matlab_test_fct_1( varargin )

    out = varargin;

end
