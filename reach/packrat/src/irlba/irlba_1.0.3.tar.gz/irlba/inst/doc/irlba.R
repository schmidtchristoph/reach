### R code from vignette source 'irlba.Rnw'

