#' Binarize a weighted (complete) network using a threshold
#'
#' Dichotomize a weighted (complete) network by means of applying a global
#' threshold t. Weights on the main diagonal and all weights < threshold t are
#' set to 0. All weights >= threshold t are set to 1. If W was directed
#' (unsymmetric) than A should be considered directed as well, even if
#' binarization made it a symmetric matrix.
#'
#' @param W weighted (complete) directed or undirected adjacency matrix or edge weight matrix
#'
#' @param t a weight threshold, e.g. a percentile value of the edge weight distribution:
#' t <- quantile(as.vector(W), 0.85)
#'
#' @return the corresponding binarized (dichotomized) adjacency matrix
#'
#' @export
#'
#' @examples
#' W       <- matrix(runif(100),10,10)
#' diag(W) <- 0
#' A       <- binarize(W, 0.4)
#' A       <- binarize(W, quantile(as.vector(W), 0.75))
#'
#' @author Christoph Schmidt <christoph.schmidt@@med.uni-jena.de>

# 27.02.15

binarize <- function(W, t){
   A        <- W;
   A[W<t]   <- 0;
   A[W>=t]  <- 1;
   diag(A)  <- 0;

   return(A)
}




#' Binarize a weighted network (binarize every weighted edge)
#' 
#' Dichotomize a weighted network by assigning every weighted edge (non-zero 
#' entry) the weight 1.
#' 
#' @param W weighted directed or undirected edge weight matrix
#'   
#' @return the corresponding binarized (dichotomized) adjacency matrix
#'   
#' @export
#' 
#' @examples
#' W                   <- matrix(runif(100),10,10)
#' diag(W)             <- 0
#' W[sample(1:100,50)] <- 0
#' A                   <- binarize_all(W)
#' 
#' @author Christoph Schmidt <christoph.schmidt@@med.uni-jena.de>

# 20.07.15

binarize_all <- function(W){
   W[W!=0] <- 1
   return(W)
}

