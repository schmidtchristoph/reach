#' Probabilistic binarization of weighted edges
#' 
#' Probabilistic binarization of weighted edges by using the weight of an edge 
#' as a probability for remaining in the resulting binary graph. Negative 
#' weights are assigned a zero-probability.
#' 
#' @param W edge weight matrix
#'   
#' @param distr a string denoting the reference probability distribution for 
#'   drawing random numbers for comparing the edge weights
#'   
#'   The value of distr can be any of the following:
#'   
#'   "unif" for the uniform distribution,
#'   
#'   "beta" for the (bimodal) beta distribution (assigns higher probabilities to
#'   lower weights)
#'   
#'   "horvath" for the mapping of any symmetric weighted matrix to a
#'   weighted adjacency matrix with edge weights between 0 and 1
#'   
#' @return A (binary) adjacency matrix
#'   
#' @export
#' 
#' @examples
#' W       <- matrix(runif(100), 10, 10)
#' diag(W) <- 0
#' distr   <- "beta"
#' A       <- probabBinarization(W, distr)
#' 
#' @author Christoph Schmidt <christoph.schmidt@@med.uni-jena.de>

# 01.09.15

probabBinarization <- function(W, distr){
   N      <- dim(W)[1]
   W[W<0] <- 0 # ignoring negative weights
   E      <- length(which(W>0))
   W      <- W/max(W) # normalizing
   
   

   if(distr=="unif"){
      r <- runif(E, 0, 1)

   } else if(distr=="beta"){
      r <-c(rbeta(5*E, 2, 4), rbeta(1*E, 2, 1))
      r <- sample(r, E)
      
   } else if(distr=="horvath"){
      return( horvath_7_6(W, 0.4) )
      
   } else {
      stop("Wrong input argument distr.")
   }



   P       <- matrix(0,N,N)
   P[W>0]  <- r
   A       <- matrix(0,N,N)
   A[P<=W] <- 1
   diag(A) <- 0

   return(A)
}





#' Maps all values of any real-valued matrix to the interval [0, 1]
#'
#' For any matrix W, this function maps the interval [min(W), max(W)]
#' monotonically increasing onto [0, 1].
#'
#' @param W edge weight matrix
#'
#' @param beta exponent of the mapping function d :=  ( (w_ij-min(W)) /
#'   (max(W)-min(W)) )^beta
#'
#' @return a weighted matrix with the mapped values
#'
#' @references S. Horvath, Weighted Network Analysis. Springer, 2011. p.162
#'
#' @examples
#' W       <- matrix(runif(16), 4, 4)
#' diag(W) <- 0
#' M       <- horvath_7_6(W, 0.4)
#'
#' @author Christoph Schmidt <christoph.schmidt@@med.uni-jena.de>

# 01.09.15

horvath_7_6 <- function(W, beta){
   if(beta < 0){ stop("Parameter beta has to be larger than 0") }

   D <- ( (W-min(W)) / (max(W)-min(W)) )^beta # minimum values is transformed to 0, maximum value is transformed to 1
   return(1/D)
}

