#' Write module affiliations to a Pajek .clu file
#'
#' Takes a vector of module assignments (as obtained from 'detectCommunities.R')
#' and writes it to a Pajek .clu file.
#'
#' @param ca vector of community affiliations for vertices
#' @param filename a string denoting the filename
#' @details Needed for using the online tool on mapequation.org to plot alluvial diagrams.
#' RAW alluvial diagrams look nicer, by the way.
#' @return None
#'
#' @export
#' @examples
#' ca <- c(1,1,1,2,2,1,3,3,3,3,3,2)
#' filename <- "moduleAffiliationExport"
#' convert2Clu(ca, filename)
#'
#' @author Christoph Schmidt <christoph.schmidt@@med.uni-jena.de>

# 13.03.15

convert2Clu <- function(ca, filename="moduleAffiliations.clu"){
   library(stringr)


   if(!str_detect(filename, ".clu")) filename <- paste(filename, ".clu", sep="")

   N <- length(ca)
   assignment <- as.character(ca)
   header <- paste("*Vertices", N)

   writeLines(c(header, assignment), con=filename)
}

