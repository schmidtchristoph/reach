#' Appends data to an existing RData file
#'
#' This function adds or updates data in an RData file and resaves it.
#'
#' @param ... the names of the objects to be saved (as symbols or character strings).
#'
#' @param list A character vector containing the names of objects to be saved.
#'
#' @param file string containing the name of the (existing) file to append data to
#' @return car the reordered and renamed community affiliations
#'
#' @export
#'
#' @examples
#' x1 <- 1
#' x2 <- 2
#' x3 <- 3
#' save(x1, x2, x3, file = "abc.RData")
#'
#' x1 <- 10
#' x2 <- 20
#' x3 <- 30
#' resave(x1, x3, file = "abc.RData")
#'
#' load("abc.RData")
#' x1
#' # [1] 10
#' x2
#' # [1] 2
#' x3
#' # [1] 30
#'
#' @author
#' flodel <http://stackoverflow.com/users/1201032/flodel>
#' Christoph Schmidt <christoph.schmidt@@med.uni-jena.de>

# 16.04.15

resave <- function(..., list = character(), file) {
   previous  <- load(file)
   varNames <- c(list, as.character(substitute(list(...)))[-1L])
   for (var in varNames) assign(var, get(var, envir = parent.frame()))
   save(list = unique(c(previous, varNames)), file = file)
}
