#' Generates weighted directed random graphs
#'
#' Executes the corresponding Matlab function: Generates either a single
#' weighted directed random graph of a specified size dim or a three dimensional
#' matrix of size (dim,dim,dim3) that contains weighted directed random graphs
#' of size dim. If not stated otherwise, edges exist with the uniform
#' probability of 0.5. Edge weights can be either generated randomly by the
#' Matlab function 'rand(N)' (which is the default: uniformly distributed in
#' open interval (0,1)) or 'betarnd(20,20).
#'
#' dim             the size of output random networks R = (dim, dim)
#'
#' dim3            the number of random graphs that are generated and stored in
#' a 3 dimensional matrix
#'
#' '-prob'         designates that a non-default probability for an edge is
#' given
#'
#' p               the probability of the existence of an edge (not the
#' probability for an edge weight); defaults to 0.5
#'
#' '-beta'         edge weight are beta distributed pseudorandom numbers
#' (betarnd(20,20)); these resemble a normal distribution in the interval [0,1];
#' if not specified, the default behavior is using uniformly distributed
#' pseudorandom numbers (rand)
#'
#'
#'
#'
#'
#'
#'
#'
#' R               asymmetrical random weighted adjacency matrix/ matrices
#'
#'
#' USAGE:
#'
#' R = randWeiDir(dim)
#'
#' R = randWeiDir(dim, dim3)
#'
#' R = randWeiDir(dim, '-prob', p)
#'
#' R = randWeiDir(dim, dim3, '-prob', p)
#'
#' R = randWeiDir(dim, '-beta')
#'
#' R = randWeiDir(dim, dim3, '-beta')
#'
#' R = randWeiDir(dim, '-prob', p, '-beta')
#'
#' R = randWeiDir(dim, dim3, '-prob', p, '-beta')
#'
#' @param dim the size of output random networks R = (dim, dim)
#'
#' @param dim3 the number of random graphs that are generated and stored in a 3
#'   dimensional matrix; defaults to 1
#'
#' @param p the probability of the existence of an edge (not the probability for
#'   an edge weight); defaults to 0.5
#'
#' @param weightDistr the edge weight distribution used; either '-beta' (edge
#'   weight are beta distributed pseudorandom numbers - the default) or '-rand'
#'   (uniformly distributed pseudorandom numbers)
#'
#' @return R asymmetrical random weighted adjacency matrix/ matrices
#'
#' @export
#'
#' @examples
#' W <- randWeiDir(10,1,0.2,'-rand')
#' print(W)
#'
#' @author Christoph Schmidt <christoph.schmidt@@med.uni-jena.de>

# 05.12.14

randWeiDir <- function(dim, dim3=1, p=0.5, weightDistr='-beta'){
  #   Executes the corresponding Matlab function:
  #
  #           %Generates either a single weighted directed random graph of a specified
  #           %size dim or a three dimensional matrix of size (dim,dim,dim3) that
  #           %contains weighted directed random graphs of size dim. If not stated
  #           %otherwise, edges exist with the uniform probability of 0.5. Edge
  #           %weights can be either generated randomly by the Matlab function 'rand(N)'
  #           %(which is the default: uniformly distributed in open interval (0,1)) or
  #           %'betarnd(20,20).
  #           %
  #           %   dim             the size of output random networks R = (dim, dim)
  #           %
  #           %   dim3            the number of random graphs that are generated and
  #           %                   stored in a 3 dimensional matrix
  #           %
  #           %   '-prob'         designates that a non-default probability for an edge
  #           %                   is given
  #           %
  #           %   p               the probability of the existence of an edge (not the
  #           %                   probability for an edge weight); defaults to 0.5
  #           %
  #           %   '-beta'         edge weight are beta distributed pseudorandom
  #           %                   numbers (betarnd(20,20)); these resemble a normal
  #           %                   distribution in the interval [0,1]; if not specified,
  #           %                   the default behavior is using uniformly distributed
  #           %                   pseudorandom numbers (rand)
  #           %
  #           %
  #           %
  #           %
  #           %
  #           %
  #           %
  #           %
  #           %   R               asymmetrical random weighted adjacency matrix/ matrices
  #           %
  #           %
  #           %           USAGE:
  #           %
  #           %   R = randWeiDir(dim)
  #           %
  #           %   R = randWeiDir(dim, dim3)
  #           %
  #           %   R = randWeiDir(dim, '-prob', p)
  #           %
  #           %   R = randWeiDir(dim, dim3, '-prob', p)
  #           %
  #           %   R = randWeiDir(dim, '-beta')
  #           %
  #           %   R = randWeiDir(dim, dim3, '-beta')
  #           %
  #           %   R = randWeiDir(dim, '-prob', p, '-beta')
  #           %
  #           %   R = randWeiDir(dim, dim3, '-prob', p, '-beta')

  inpErr <- TRUE

  if (weightDistr=='-beta') {
    lastArg <- ",'-beta'"
    inpErr <- FALSE
  }


  if (weightDistr=='-rand') {
    lastArg <- ""
    inpErr <- FALSE
  }



  if (inpErr) { stop('Wrong input argument weightDistr.') }







  # rng('shuffle'): so that Matlab uses different random numbers at each start-up
  matlabCode <- c("rng('shuffle');",
                  paste("R = randWeiDir(", as.character(dim), ",", as.character(dim3), ",", "'-prob'", ",", as.character(p), lastArg, ");"),
                  "save randWeiDir_tmp.mat R -v7")

  writeLines(matlabCode, con="randWeiDir_R_script.m")


  reach::runMatlabScript('randWeiDir_R_script')
  system('rm randWeiDir_R_script.m')

  inp <- R.matlab::readMat('randWeiDir_tmp.mat')
  R   <- inp$R

  system('rm randWeiDir_tmp.mat')


  return(R)
}

