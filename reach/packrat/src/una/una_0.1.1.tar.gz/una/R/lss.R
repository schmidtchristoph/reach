#' Nicely formatted overview of workspace objects using most memory
#'
#' Displays an improved summary list of workspace objects, sorted according to
#' their memory usage in descending order.
#'
#' @param n the number of biggest size workspace objects to be displayed. This
#'   parameter is optional and the standard is to show all workspace objects.
#'
#' @export
#'
#' @examples
#' x1 <- 1
#' x2 <- 2
#' x3 <- data.frame(one=x1, two=x2)
#' lss()
#'
#' @author Dirk Eddelbuettel <http://stackoverflow.com/users/143305/dirk-eddelbuettel>
#'
#'   Tony Breyal <http://stackoverflow.com/users/300123/tony-breyal>
#'
#'   Christoph Schmidt <christoph.schmidt@@med.uni-jena.de>

# 14.07.15

# shorthand
lss <- function(..., n=length(ls(globalenv()))) {
   writeLines(paste("Number of workspace objects: ", length(ls(globalenv()))))
   writeLines("Memory used by R session:")
   print(pryr::mem_used())
   writeLines("")

   if(length(ls(globalenv()))!=0){
      .ls.objects(..., order.by="Size", decreasing=TRUE, head=TRUE, n=n)

   } else {
      writeLines("NO WORKSPACE OBJECTS")
   }
}



# improved list of objects
.ls.objects <- function (pos = 1, pattern, order.by, decreasing=FALSE, head=FALSE, n) {
   napply <- function(names, fn) sapply(names, function(x)
      fn(get(x, pos = pos)))
   names <- ls(pos = pos, pattern = pattern)
   obj.class <- napply(names, function(x) as.character(class(x))[1])
   obj.mode <- napply(names, mode)
   obj.type <- ifelse(is.na(obj.class), obj.mode, obj.class)
   obj.prettysize <- napply(names, function(x) {
      capture.output(format(utils::object.size(x), units = "auto")) })
   obj.size <- napply(names, object.size)
   obj.dim <- t(napply(names, function(x)
      as.numeric(dim(x))[1:2]))
   vec <- is.na(obj.dim)[, 1] & (obj.type != "function")
   obj.dim[vec, 1] <- napply(names, length)[vec]
   out <- data.frame(obj.type, obj.size, obj.prettysize, obj.dim)
   names(out) <- c("Type", "Size", "PrettySize", "Rows", "Columns")
   if (!missing(order.by))
      out <- out[order(out[[order.by]], decreasing=decreasing), ]
   if (head)
      out <- head(out, n)
   out
}



