#' Checks whether an input matrix is symmetric
#'
#' Returns 1 if input matrix is symmetric, 0 otherwise.
#' An undirected graph has a symmetric adjacency matrix (1), a directed graph
#' has an unsymmetric adjacency matrix (0). Every symmetric matrix is a square matrix.
#'
#' @param A (adjacency) matrix
#' @return boolean indicating whether input A is symmetric (undirected)
#'
#' @keywords matrix
#' @export
#' @examples
#' A <- matrix(sample(c(0,1), 9, replace=TRUE), 3, 3)
#' print(A)
#' issym(A)
#'
#' @author Christoph Schmidt <christoph.schmidt@@med.uni-jena.de>

# 13.11.14

issym <- function(A){
   bool <- all(A==t(A)) # = !is.directed(graph.adjacency(A))

   return(bool)
}
