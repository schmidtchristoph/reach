#' Delete all occurrences of a specified field in a bibtex file
#'
#' Deletes all occurrences of a specified field in a bibtex file and writes a
#' new processed version in the same directory.
#'
#' @param filename string denoting the filename "name.bib"
#'
#' @param fieldname string denoting the bibtex field that should be removed from
#'   all entries in the input file
#'
#' @export
#'
#' @examples
#' \dontrun{
#' deleteFieldBibFile("Papers3.bib","annote")
#' }
#'
#' @author Christoph Schmidt <christoph.schmidt@@med.uni-jena.de>

# 05.02.15

deleteFieldBibFile <- function(filename, fieldname){

   f        <- readLines(filename)
   loc      <- stringr::str_extract(f, fieldname)
   ind      <- which(is.na(loc) %in% FALSE)  # indices of lines where the pattern starts (might span multiple lines)
   linesDel <- numeric(0)


   for (k in 1:length(ind)){
      thisind  <- ind[k]


      while (TRUE){
         linesDel <- c(linesDel,thisind)
         len      <- nchar(f[thisind])
         lastPos  <- stringr::str_locate_all(f[thisind],"}")
         lastPos  <- lastPos[[1]][nrow(lastPos[[1]]),2]


         if (length(lastPos)==0){ # if isempty(), i.e. we encountered an empty line in the file
            thisind <- thisind+1
            next
         }


         if (lastPos==len | lastPos==len-1){ # found end of field
            break

         } else {
            thisind <- thisind+1
         }
      }
   }


   writeLines(f[-linesDel], paste(stringr::str_sub(filename, 1, -5), "_pr", ".bib", sep=""))
}

