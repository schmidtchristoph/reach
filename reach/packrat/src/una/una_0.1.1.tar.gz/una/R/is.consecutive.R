#' Check whether all values of an integer vector are consecutive
#'
#' Returns a boolean value indicating whether the integer input vector contains (not necessarily ordered)
#' consecutive numbers, i.e. there are no gaps in its unique values: all its ordered unique values are
#' consecutive numbers starting with 1.
#'
#' @param vec an integer vector
#'
#' @return a boolean indicating whether the values of vec are consecutive/ have no "gaps"
#'
#' @export
#'
#' @examples
#' v1 <- c(1,3,5,1,4)
#' print(sort(unique(v1)))
#' isc <- is.consecutive(v1)
#' print(isc)
#'
#' v2 <- c(1,3,5,1,4,2,4)
#' print(sort(unique(v2)))
#' isc <- is.consecutive(v2)
#' print(isc)
#'
#' @author
#' Christoph Schmidt <christoph.schmidt@@med.uni-jena.de>

# 20.03.15

is.consecutive <- function(vec){
   return(length(intersect(seq(1,length(unique(vec))), unique(vec)))==length(unique(vec)))
}

