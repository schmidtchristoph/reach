#' Shortcut for rm(list=ls()) to remove all workspace objects
#'
#' Shortcut for rm(list=ls()) to remove all workspace objects.
#'
#' @export
#'
#' @examples
#' x1 <- 1
#' x2 <- 2
#' x3 <- data.frame(one=x1, two=x2)
#' lss()
#' rmm()
#' lss()
#'
#' @author Christoph Schmidt <christoph.schmidt@@med.uni-jena.de>

# 15.07.15


rmm <- function(){
   rm(list=ls(globalenv()), envir = globalenv())
}
