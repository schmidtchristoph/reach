#' Generates single binary directed ER random graphs
#'
#' Generates either a single binary directed ER random graph of a specified size
#  dim or a three dimensional matrix of size (dim,dim,dim3) that contains binary
#  directed ER random graphs of size dim. If not stated otherwise, edges have
#  the uniform probability of 0.5.
#'
#' @param dim the size of output random networks R = (dim, dim); defaults to 5
#'
#' @param dim3 the number of random graphs that are generated and stored in a 3 dimensional matrix; defaults to 1
#'
#' @param p the probability of an edge; defaults to 0.5
#'
#' @details ER = Erdös-Renyi random graph G(n,p)
#'
#' @return asymmetrical Erdös-Renyi random graph adjacency matrix/ matrices
#'
#' @export
#'
#' @examples
#' R <- randDir(8)
#' print(R)
#'
#' R <- randDir(5, 2, 0.1)
#' print(R)
#'
#' @author
#' Christoph Schmidt <christoph.schmidt@@med.uni-jena.de>

# 20.11.14

randDir <- function(dim=5, dim3=1, p=0.5){
   library(igraph)


   if (dim3==1){
      R <- igraph::get.adjacency(erdos.renyi.game(dim, p, type="gnp", directed = TRUE, loops = FALSE), sparse=FALSE)

   } else if (dim3>1){
      R<-array(0,c(dim,dim,dim3)) #init random matrix R  (R=zeros(dim,dim,dim3))

      for (m in 1:dim3){
         R_<-igraph::get.adjacency(erdos.renyi.game(dim, p, type="gnp", directed = TRUE, loops = FALSE), sparse=FALSE)
         R[,,m]<-R_
      }
   } else{
      stop('Wrong input argument dim3.')
   }



  return(R)
}
