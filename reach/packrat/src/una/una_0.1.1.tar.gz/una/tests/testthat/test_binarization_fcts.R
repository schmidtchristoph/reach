library(una)

context("probabilistic binarization (binarize_prob)")



test_that("binarize_prob terminates on correct input", {
   W       <- matrix(runif(100), 10, 10)
   diag(W) <- 0

   expect_that(probabBinarization(W, "unif"), not(throws_error()))
   expect_that(probabBinarization(W, "beta"), not(throws_error()))
   expect_that(probabBinarization(W, "horvath"), not(throws_error()))
})
