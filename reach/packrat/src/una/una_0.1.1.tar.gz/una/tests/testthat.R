library(testthat)
library(una)

test_check("una")
