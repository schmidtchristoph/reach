library("R.utils")

x <- 1:10
print(x)
y <- intToHex(x)
print(y)
y <- intToBin(x)
print(y)
y <- intToOct(x)
print(y)

